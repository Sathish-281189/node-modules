import { ModuleWithProviders } from '@angular/core';
export declare class FroalaEditorModule {
    static forRoot(): ModuleWithProviders;
}
