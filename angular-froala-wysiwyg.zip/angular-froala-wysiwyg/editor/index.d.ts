export { FroalaEditorDirective } from './editor.directive';
export { FroalaEditorModule } from './editor.module';
