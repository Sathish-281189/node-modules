export { FroalaViewDirective } from './view.directive';
export { FroalaViewModule } from './view.module';
//# sourceMappingURL=index.js.map