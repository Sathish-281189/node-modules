export { FroalaViewDirective } from './view.directive';
export { FroalaViewModule } from './view.module';
